export const AUTH_CONFIG = {
  clientId: 'TcHzYEyEzpJ0gYtYVyavXXjidRjQ7Yqw',
  domain: 'techiediaries.auth0.com',
  callbackUrl: 'http://localhost:8000/callback',
  apiUrl: 'https://djangovuedemo.techiediaries.com'
}
